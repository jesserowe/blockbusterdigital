

   const words=["quibi","kyle rogers"];
   const replacements=["blockbuster", "KPRogers" ];
   
   const replacementHash = new Map();
   
   function titleCase(string) {
       var sentence = string.toLowerCase().split(" ");
       for(var i = 0; i< sentence.length; i++){
          sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
       }
    
    return sentence.join(" ");
    }
    words.map((word, index)=>{

      replacementHash.set(word.toUpperCase(), replacements[index].toUpperCase());
      replacementHash.set(word.toLowerCase(), replacements[index].toLowerCase());
      replacementHash.set(titleCase(word), titleCase(replacements[index]));
      
    })
  

let replacer = (element) =>{
   element.childNodes.forEach(child =>{
     if(child.nodeType === 3){
         let value =  child.nodeValue
       
     
            Array.from(replacementHash.keys()).map((key)=>{
               const regex = new RegExp("\\b"+key+"\\b","g")

               if(value.match(regex)){

                  const replacement = replacementHash.get(key)
                  value = value.replace(regex,replacement )
                  child.nodeValue= value;
               }


            })

     
     }
   });

 }

let replaceWords = ()=>{



   const elements = [...document.body.getElementsByTagName('*')];

   elements.forEach(replacer);
     
 
   
}
const debounce = (func, delay) => { 
   let debounceTimer 
   return function() { 
       const context = this
       const args = arguments 
           clearTimeout(debounceTimer) 
               debounceTimer 
           = setTimeout(() => func.apply(context, args), delay) 
   } 
}  
const debouncedFunction =    debounce(()=>{
 
   replaceWords()
  }, 200);

(function(){
chrome.storage.local.get(["enabled"], function(results){
   if(results.enabled){
      console.log("Extension is enabled. Will replace")
      replaceWords();

      //Set up a mutation observer
      const config = { attributes: false, childList: true, subtree: true };
      const node = document.body

      const callback = function(mutationsList, observer) {
         // Use traditional 'for loops' for IE 11
         for(let mutation of mutationsList) {
             if (mutation.type === 'childList') {
               debouncedFunction()   
             }
           
         }
     };

     const observer = new MutationObserver(callback);
     observer.observe(node, config);

     document.addEventListener("visibilitychange", function () {
      if (document.hidden) {
         observer.disconnect
        console.log("Document is hidden. Will stop observing")
      }else{
         console.log("Document is visible again. Will start observing")

         observer.observe(node, config);

      }
    }, false);
    

   }
})
})();
