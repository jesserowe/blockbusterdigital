let enableContextMenuId=0;
let enabled=true


chrome.runtime.onInstalled.addListener(details => {
   chrome.storage.local.set({enabled: true})
});
chrome.storage.local.get(["enabled"], function(results){

    enabled=results.enabled
    enableContextMenuId= chrome.contextMenus.create({
        "type":"normal",
        "checked":enabled,
        "title": enabled ? "Turn Blockbuster Digital Off" : "Turn Blockbuster Digital On",
        "contexts":["browser_action"],
        "onclick":function() {
           toggleEnableContextMenu()
        },
        'visible':true
      });
      
    

})
const toggleEnableContextMenu=()=>{
    enabled= !enabled
    chrome.storage.local.set({enabled}, function(){
        chrome.contextMenus.update(enableContextMenuId,{ title: enabled ? "Turn Blockbuster Digital Off" : "Turn Blockbuster Digital On"})

    })
}


chrome.runtime.onMessage.addListener((message, sender, respond)=>{
    const {type, payload} = message
    console
    switch(type){
        case "toggle": 
            toggleEnableContextMenu();
        
    }

})

chrome.commands.onCommand.addListener((command)=>{
    console.log("Command Received")
    switch(command){
        case "toggle_extension":
            toggleEnableContextMenu();

    }

});