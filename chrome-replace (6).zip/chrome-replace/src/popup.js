let enabled = true

function updateStatusText(status){
    document.getElementById("extension-status").innerText= status ? "Off": "On"

}
chrome.storage.local.get(["enabled"],function(results){
   enabled= results.enabled
    updateStatusText(enabled)

})

document.getElementById("toggle").addEventListener("click", function(){
  enabled=!enabled
  chrome.runtime.sendMessage({type:"toggle"})
  updateStatusText(enabled)
})

document.addEventListener('DOMContentLoaded', function () {
  for (const anchor of document.getElementsByTagName('a')) {
    anchor.onclick = () => {
      chrome.tabs.create({active: true, url: anchor.href});
    };
  };
});
